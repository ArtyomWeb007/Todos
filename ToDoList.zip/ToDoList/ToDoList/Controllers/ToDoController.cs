﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ToDoList.Data;
using ToDoList.Models;

namespace ToDoList.Controllers
{
    public class ToDoController : Controller
    {
        private readonly ToDoDbContext _context;

        public ToDoController(ToDoDbContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            return View(_context.todos.ToList());
        }

        public IActionResult Add()
        {
            return View();
        }

        public IActionResult AddModel(string TodoName)
        {
            _context.Add(new ToDoModel { ToDoName = TodoName, ToDoStatus = "False" });
            _context.SaveChanges();
            return RedirectToAction(nameof(Index));
        }
        public IActionResult Delete()
        {
            return View();
        }
        public IActionResult DeleteModel(int IdForDlting)
        {
            if (_context.todos.Contains(new ToDoModel { ToDoId = IdForDlting }))
            {
                _context.todos.Remove(new ToDoModel { ToDoId = IdForDlting });
                _context.SaveChanges();
            }
            return RedirectToAction(nameof(Index));
        }
            
    }
}

﻿let
todo = document.querySelector(".ToDo"),
blur = document.querySelector(".blur");

window.onload = () => { todo.style.transform = "translateX(-250px)";};

setTimeout(() => {
    todo.style.transform = "translateX(0px)"
    todo.style.width = "500px"
}, 1000)
﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace ToDoList.Models
{
    public class ToDoModel
    {

        [Key]
        public int ToDoId { get; set; }

        [Required, MaxLength(25)]
        public string ToDoName { get; set; }

        [Required, DefaultValue("False")]
        public string ToDoStatus { get; set; }
    }
}
